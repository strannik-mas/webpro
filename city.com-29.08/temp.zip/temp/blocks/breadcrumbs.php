<div class="row">
	<div class="location">
		<a href="#">Главная</a>
		<span>Чат Москвы</span>
	</div>
</div>