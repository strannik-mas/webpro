<footer>
	<div class="container-fluid">
		<div class="container">
			<div class="row">
				<div class="copy">
					<img src="ops/chat/img/mini-logo.png" alt="logo"/><span>© 2017.  Город Дорог. Все права защищены.</span>
				</div>
				<div class="footer-list">
					<ul>
						<li><a href="#">Чат</a></li>
						<li><a href="#">Карта</a></li>
						<li><a href="#">Объявления</a></li>
						<li><a href="#">Пользовательское соглашение</a></li>
						<li><a href="#">Помощь</a></li>
						<li><a href="#">Сообщить об ошибке </a></li>
					</ul>
					
				</div>
			</div>
		</div>                          
	</div>
		
</footer>

<span class="btn-scroll-top">Наверх<i class="fa fa-long-arrow-up"></i></span>
</body>
</html>