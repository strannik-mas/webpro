<?php
	$ops_folder = $_GET['ops'];
	require_once ('ops/' . $ops_folder . '/index.php');
?>