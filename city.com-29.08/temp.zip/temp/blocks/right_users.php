<div class="all-users" id="divUsers">
	<h3>Пользователи</h3>
	<p><span>18 369 online</span></p>	
</div>

<div class="search-user">
	<div class="form-group search-inner">
		<a href="#" class="fa fa-search"></a>
		<input name="search" placeholder="Найти пользователя" required="" type="search" class="form-control">
	</div>
</div>