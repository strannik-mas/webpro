<div class="banner">
	<img src="ops/chat/img/banner.png" alt="banner" class="img-responsive" />
</div>