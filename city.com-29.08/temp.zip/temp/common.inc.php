<?php
require_once('common/dbconnect.php');
require_once('common/functions.php');
require_once('common/functions_ak.php');
error_reporting(E_ALL & ~E_NOTICE);
ini_set('display_errors', 1);
?>